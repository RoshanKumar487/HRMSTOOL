package HRMS.HRMSPRO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrmsproApplicationTests {

	@Test
	void contextLoads() {
	}

}
